import React from "react";

function Loading() {
  return <div style={{ padding: 15, fontSize: 18 }}>Loading...</div>;
}

export default Loading;
