import React from "react";

function Header() {
  return <h1 className="text-center my-4">Notes App</h1>;
}

export default React.memo(Header);
