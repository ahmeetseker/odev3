import getData from "./data.js";

const userData = await getData(7);

console.log(userData);
