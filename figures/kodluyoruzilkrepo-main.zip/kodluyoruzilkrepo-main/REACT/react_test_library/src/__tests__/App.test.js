import { render, screen } from "@testing-library/react";
import App from "../App";

test("App Component must work", () => {
  render(<App />);
});
