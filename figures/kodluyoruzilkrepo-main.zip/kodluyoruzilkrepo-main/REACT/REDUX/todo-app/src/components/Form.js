import React from "react";

function Form() {
  return (
    <form>
      <input
        className="new-todo"
        placeholder="What needs to be done?"
        autofocus
      />
    </form>
  );
}

export default Form;
